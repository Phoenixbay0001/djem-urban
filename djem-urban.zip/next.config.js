module.exports = {
  reactStrictMode: true,
};